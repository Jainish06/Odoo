# -*- coding: utf-8 -*-

from . import res_student
from . import subject_subject
from . import previous_year_marks
from . import tuition_fee_structure
