# -*- coding: utf-8 -*-
from . import doctor_details
from . import patient_details
from . import departments
from . import staff_details
from . import insurance_details
from . import appointment_details
from . import prescription_details
from . import prescription_line