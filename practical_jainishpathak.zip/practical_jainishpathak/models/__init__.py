# -*- coding: utf-8 -*-

from . import pharmacy_master
from . import product_template
from . import stock_picking
from . import mail_activity_schedule
from . import res_config_setting
from . import sale_order
from . import purchase_order