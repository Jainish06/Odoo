from odoo import api, fields, models

class PurchaseOrder(models.Model):
    _inherit = 'purchase.order'

    def button_confirm(self):
        res = super(PurchaseOrder, self).button_confirm()
        template_id = self.env.ref('practical_jainishpathak.email_template_send_vendor')
        if self.partner_id.email:
            template_id.send_mail(self.id, force_send=False)
        return res